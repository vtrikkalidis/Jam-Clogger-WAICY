Please unzip in a local folder and open with a browser, the html files:

_TafficLight_FIXED-TIME.html  and 
_TafficLight_JAM-CLOGGER.html